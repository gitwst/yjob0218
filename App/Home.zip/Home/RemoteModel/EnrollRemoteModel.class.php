<?php
namespace Home\RemoteModel;

class EnrollRemoteModel
{

}