<?php
namespace Home\Controller;
use Think\Controller;
class PublicController extends Controller{
    public function _initialize(){
    	$user = isset($_SESSION['uid']) ? $_SESSION['uid'] : null;
    	if(!$user){
    		$this->error('未登录，请登录',U('Login/login'),3);
    	}
    }
}