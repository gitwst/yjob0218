<?php
namespace Home\Controller;
use Think\Controller;
use Home\RemoteModel\JobRemoteModel;
class IndexController extends Controller {
    public function index(){
        $JobRemoteModel = new JobRemoteModel();
        $result = $JobRemoteModel->jobList();
        var_dump($result);
    }
}