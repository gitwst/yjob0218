<?php
namespace Home\Controller;
use Think\Controller;
use Home\RemoteModel\UserRemoteModel;
class PerredcenterController extends Controller {

    public function index(){
        $this->display();
    }
}