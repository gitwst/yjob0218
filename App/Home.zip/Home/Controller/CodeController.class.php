<?php
namespace Home\Controller;
use Think\Controller;
use Home\RemoteModel\UserRemoteModel;
class CodeController extends Controller {
    public function sendcode(){
        if(IS_POST){
            $loginData = array();
            $loginData['mobile'] = $_POST['phone'];
            $loginData['type'] = $_POST['type'];
            $UserRemoteModel = new UserRemoteModel();
            $resultLogin = $UserRemoteModel->smsSend($loginData);
            if($resultLogin['codes'] == '0'){
                $this->ajaxReturn(array('code' => 1, 'msg' => '验证码发送成功'));
            }else{
                $this->ajaxReturn(array('code' => 2, 'msg' => '验证码发送失败'));
            }
        }
    }

    public function getcode(){
        
    }
}