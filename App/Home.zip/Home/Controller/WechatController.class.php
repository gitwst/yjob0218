<?php
namespace Home\Controller;
use Think\Controller;
use Home\RemoteModel\UserRemoteModel;
class WechatController extends Controller {

    public function index(){
        $this->assign('we_chat', 600);
        $this->display('Login/login');
    }

    public function bind_we_chat(){
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        if (strpos($user_agent, 'MicroMessenger') === false) {
            // 非微信浏览器禁止浏览
            echo '放一个二维码。请在关注此公众号后，再进行绑定！';
        } else {
            header("Location:https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx32245a3f15a7c46f&redirect_uri=http%3A%2F%2Fstatic.yjob.net%2Foauth2.php&response_type=code&scope=snsapi_userinfo&state=1#wechat_redirect");
        }
        exit;
    }

    public function we_chat_bind(){
        $openId = I('get.openid')?I('get.openid'):false;
        $nickName = I('get.nick_name')?I('get.nick_name'):false;
        if(!$openId || !$nickName){
            exit('绑定失败');
        }
        $postData = array();
        $_SESSION['uid'] && $postData['uid'] = $_SESSION['uid'];
        $_SESSION['mobile'] && $postData['mobile'] = $_SESSION['mobile'];
        if(!$_SESSION['uid'] || !$_SESSION['mobile']){
            // 跳转到微信绑定页面
            $this->assign('we_chat', 600);
            $this->assign('openid', $openId);
            $this->assign('nick_name', $nickName);
            $this->display('Login/login');
            exit;
        }
        $postData['plateform'] = 100;
        $postData['third_uid'] = $openId;
        $postData['nike_name'] = $nickName;
        $UserRemoteModel = new UserRemoteModel();
        $result = $UserRemoteModel->userThirdParty($postData);
        if($result['code'] == '0'){
            echo '绑定成功';
        }else{
            exit('绑定失败');
        }
    }
}