<?php
namespace Home\Controller;
use Think\Controller;
use Home\RemoteModel\UserRemoteModel;
class RegisterController extends Controller {
    public function index(){
        if(IS_POST){
            $postData = array();
            $postData['user_name']     = $_POST['register_phone'];
            $postData['password']      = $_POST['register_pass'];
            $postData['identify_code'] = $_POST['register_code'];
            $postData['type']          = $_POST['register_type'];
            $postData['mobile']        = $_POST['register_phone'];
            $postData['register_ip']   = get_client_ip();
            $postData['invite_code']   = $_POST['register_invite_code']?$_POST['register_invite_code']:'';
            $postData['invite_uid']    = '';
            $UserRemoteModel = new UserRemoteModel();
            $result = $UserRemoteModel->userRegister($postData);
            if($resule['codes'] == '0'){
                $this->ajaxReturn(array('code' => 1, 'msg' => '注册成功'));
            }else{
                $this->ajaxReturn(array('code' => 2, 'msg' => '注册失败'));
            }
        }
    }

    // 加载企业注册模板
    public function qyzc(){
        $this->display();
    }

    // 加载个人注册模板
    public function grzc(){
        $this->display();
    }
}