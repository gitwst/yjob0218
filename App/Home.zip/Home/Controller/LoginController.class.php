<?php
namespace Home\Controller;
use Think\Controller;
use Home\RemoteModel\UserRemoteModel;
class LoginController extends Controller {
    public function index(){
        $this->display('login');
    }

    public function login(){
        if(IS_POST){
            $loginData = array();
            // 获取登录IP
            $loginData['login_ip'] = get_client_ip();
            $loginType = $_POST['type'];
            if($loginType == 100){
                $loginData['login_type'] = 100;
                $_POST['m_pass'] && $loginData['password'] = $_POST['m_pass'];
            }else{
                $loginData['login_type'] = false;
                $_POST['code'] && $loginData['identify_code'] = $_POST['code'];
            }
            $loginData['user_name'] = $_POST['m_phone'];
            $UserRemoteModel = new UserRemoteModel();
            $resultLogin = $UserRemoteModel->userLogin($loginData);
            if($resultLogin['codes'] == '0'){
                session('uid', $resultLogin['data']['user_id']);
                session('mobile', $_POST['m_phone']);
                // 如果是微信绑定
                if(I("post.we_chat") == 600 && I("post.openid") && I("post.nick_name")){
                    $we_chatData = array();
                    $we_chatData['uid']        = $resultLogin['data']['user_id'];
                    $we_chatData['mobile']     = I("post.m_phone");
                    $we_chatData['plateform']  = 100;
                    $we_chatData['openId']     = I("post.openid");
                    $we_chatData['nickName']   = I("post.nick_name");
                    $bindResult = $UserRemoteModel->userThirdParty($we_chatData);
                    if($bindResult['code'] == '0'){
                        $this->ajaxReturn(array('code' => 3, 'msg' => '绑定成功'));
                    }else{
                        $this->ajaxReturn(array('code' => 4, 'msg' => '绑定失败'));
                    }
                }
                $this->ajaxReturn(array('code' => 1, 'msg' => '登录成功'));
            }else{
                $this->ajaxReturn(array('code' => 2, 'msg' => '验证失败'));
            }
        }else{
            $this->display();
        }
    }

    public function loginout(){
        session_unset('uid');
        session_unset('mobile');
        $this->redirect('Login/index');
    }
}