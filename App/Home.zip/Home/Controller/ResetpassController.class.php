<?php
namespace Home\Controller;
use Think\Controller;
use Home\RemoteModel\UserRemoteModel;
class ResetpassController extends Controller {

    public function index(){
        $this->display();
    }

    // 用户重置密码
    public function resetpass(){
        if(IS_POST){
            $postData = array();
            $postData['mobile'] = $_POST['reset_phone'];
            $postData['password'] = $_POST['reset_pass'];
            $postData['identify_code'] = $_POST['reset_code'];
            $UserRemoteModel = new UserRemoteModel();
            $result = $UserRemoteModel->userResetPassWd($postData);
            if($result['codes'] == '0'){
                $this->ajaxReturn(array('code' => 1, 'msg' => '重置成功'));
            }else{
                $this->ajaxReturn(array('code' => 2, 'msg' => '重置失败'));
            }
        }
    }
}