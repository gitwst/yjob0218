<?php
namespace Home\Controller;
use Think\Controller;
use Home\RemoteModel\UserRemoteModel;
class PopuController extends Controller {
    public function index(){
        $this->display();
    }
}