<?php
return array(
	'XT_PAGENUM'  => 10,//后台每页显示条数
	//url访问模式为rewrite模式
	'URL_MODEL' => '2' ,
	//开启伪静态
	'URL_HTML_SUFFIX'  => '' ,
	'LOAD_EXT_CONFIG' => 'apiConf',
);